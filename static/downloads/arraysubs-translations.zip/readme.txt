ARRAYSUBS TRANSLATION PACK

This pack contains 30 non-English locales for ArraySubs and ArraySubs Pro.
English is the source language; US, UK, and other English variants are excluded.
The catalogs match ArraySubs 2.1.0 and ArraySubs Pro 1.3.0.

CONTENTS

readme.txt
arraysubs/       Core .po, .mo, and .l10n.php translation files
arraysubspro/    Pro .po, .mo, and .l10n.php translation files

Each locale in this ZIP has a .po, .mo, and .l10n.php file. Keep their names unchanged.
POT templates and JSON script catalogs stay intact in each plugin languages
directory. They are not moved into this ZIP. Leave those plugin files in place.
This is a translation pack, not an installable WordPress plugin ZIP.

INSTALL A LANGUAGE

1. Extract the ZIP on your computer and pick your WordPress locale.
   For example, Spanish (Spain) uses es_ES.
2. Copy that locale's files from arraysubs into:
   wp-content/languages/plugins/
   Create the directory if it does not exist.
3. If you use ArraySubs Pro, copy its matching locale files from arraysubspro
   into the same directory. Pro files do not install or activate ArraySubs Pro.
4. Keep all three matching files together. For Spanish, core uses:
   arraysubs-es_ES.po
   arraysubs-es_ES.mo
   arraysubs-es_ES.l10n.php
   Pro uses the same names with the arraysubspro prefix.
5. Change the site language in Settings > General, or your admin language in
   Users > Profile. TranslatePress or Polylang can select a visitor language.
6. Clear page caches, reload the site, and check the translated pages.

The shared languages/plugins directory keeps the files outside the plugins.
You can instead copy them into each plugin's languages directory:
wp-content/plugins/arraysubs/languages/
wp-content/plugins/arraysubspro/languages/
Keep a backup before plugin updates when you use those locations.

EDIT TRANSLATIONS

Loco Translate edits built-in plugin text. Choose its Custom location for
edited catalogs. Use the arraysubs.pot or arraysubspro.pot template already
present in the matching plugin languages directory when syncing. Do not recreate it from source in Loco;
that loses the build references used by JavaScript translations.

TranslatePress or Polylang translates saved text such as custom button labels
and restriction messages through the languages icon beside supported fields.
Use one saved-text provider at a time. Product names and descriptions are
WooCommerce content and need their own translation setup.

KEEP FILES ALIGNED

.po is the editable source. .mo and .l10n.php provide PHP translations.
The plugins retain their .pot templates and .json script translations.
Replace matching .mo and .l10n.php together. When editing in Loco Translate,
keep JSON compilation enabled so custom script translations stay aligned. If your editor does not
rebuild .l10n.php, remove the older PHP file from that location so WordPress
can use the updated .mo. Preserve placeholders such as %s, %d, and {site_name},
and keep HTML tags intact.

Download a fresh pack when plugin strings change. Untranslated or new strings
fall back to the source text. Check the locale, paths, and cache if needed.
The Multilingual module card itself always stays in English.

PUBLIC DOWNLOAD AND GUIDE

https://support.arrayhash.com/arraysubs/assets/downloads/arraysubs-translations.zip
https://support.arrayhash.com/arraysubs/multilingual/
